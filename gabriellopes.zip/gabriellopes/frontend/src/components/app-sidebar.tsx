import { 
  LayoutDashboard, 
  Users, 
  FolderKanban, 
  CheckSquare, 
  DollarSign, 
  Clock, 
  MessageSquare, 
  Bell,
  LogOut,
  Sparkles
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { useAuth } from "@/contexts/AuthContext";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

const menuItems = [
  {
    title: "Dashboard",
    url: "/dashboard",
    icon: LayoutDashboard,
    badge: null,
  },
  {
    title: "Clientes",
    url: "/clientes",
    icon: Users,
    badge: null,
  },
  {
    title: "Projetos",
    url: "/projetos",
    icon: FolderKanban,
    badge: null,
  },
  {
    title: "Tarefas",
    url: "/tarefas",
    icon: CheckSquare,
    badge: "3",
  },
  {
    title: "Financeiro",
    url: "/financeiro",
    icon: DollarSign,
    badge: null,
  },
  {
    title: "Timesheet",
    url: "/timesheet",
    icon: Clock,
    badge: null,
  },
  {
    title: "Chat",
    url: "/chat",
    icon: MessageSquare,
    badge: null,
  },
  {
    title: "Avisos",
    url: "/avisos",
    icon: Bell,
    badge: "2",
  },
];

export function AppSidebar() {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  const getInitials = (nome: string) => {
    return nome
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const getRoleBadge = (role: string) => {
    const badges = {
      admin: { label: "Admin", color: "bg-gradient-to-r from-purple-500 to-pink-500" },
      gerente: { label: "Gerente", color: "bg-gradient-to-r from-blue-500 to-cyan-500" },
      funcionario: { label: "Funcionário", color: "bg-gradient-to-r from-emerald-500 to-teal-500" },
    };
    return badges[role as keyof typeof badges] || badges.funcionario;
  };

  const roleBadge = user ? getRoleBadge(user.role) : null;

  return (
    <Sidebar className="border-r-0 bg-gradient-to-b from-gray-900 via-gray-900 to-gray-950">
      <SidebarContent>
        <div className="px-6 py-6 border-b border-white/10">
          <div className="flex items-center gap-3 mb-2">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-lg blur-md opacity-75 animate-pulse" />
              <div className="relative bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 p-2 rounded-lg">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-lg font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                Lopes Designer
              </h1>
              <p className="text-xs text-gray-400">Sistema de Gestão</p>
            </div>
          </div>
        </div>

        <SidebarGroup className="px-3 py-4">
          <SidebarGroupLabel className="text-gray-400 text-xs font-semibold uppercase tracking-wider px-3 mb-2">
            Navegação
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              {menuItems.map((item) => {
                const isActive = location === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton 
                      asChild 
                      isActive={isActive} 
                      data-testid={`link-${item.title.toLowerCase()}`}
                      className={`
                        group relative overflow-hidden transition-all duration-300
                        ${isActive 
                          ? 'bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 text-white shadow-lg shadow-purple-500/20' 
                          : 'text-gray-300 hover:text-white hover:bg-white/5'
                        }
                      `}
                    >
                      <Link href={item.url} className="flex items-center justify-between w-full">
                        <div className="flex items-center gap-3">
                          <item.icon className={`w-5 h-5 transition-transform duration-300 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`} />
                          <span className="font-medium">{item.title}</span>
                        </div>
                        {item.badge && (
                          <Badge className="bg-gradient-to-r from-pink-500 to-purple-500 text-white border-0 shadow-lg">
                            {item.badge}
                          </Badge>
                        )}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-white/10">
        <div className="p-4">
          <div className="flex items-center gap-3 mb-4 p-3 rounded-xl bg-gradient-to-r from-white/5 to-white/10 backdrop-blur-sm border border-white/10">
            <Avatar className="h-12 w-12 ring-2 ring-purple-500/50 ring-offset-2 ring-offset-gray-900">
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-bold text-lg">
                {user ? getInitials(user.nome) : "U"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">
                {user?.nome || "Usuário"}
              </p>
              {roleBadge && (
                <Badge className={`${roleBadge.color} text-white text-xs border-0 mt-1 shadow-lg`}>
                  {roleBadge.label}
                </Badge>
              )}
            </div>
          </div>
          <Button
            variant="outline"
            className="w-full bg-red-500/10 hover:bg-red-500/20 text-red-400 hover:text-red-300 border-red-500/30 hover:border-red-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-red-500/20"
            onClick={() => logout()}
            data-testid="button-logout"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Sair
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
